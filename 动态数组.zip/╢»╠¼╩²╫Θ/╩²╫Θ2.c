#include"stdio.h"
#include"stdlib.h"
int main()
{
    int m,n;
    scanf("%d %d",&m,&n);
    int a[m][n];
    for(int i=0;i<m;i++)
        for(int j=0;j<n;j++)
            scanf("%d",&a[i][j]);
    int l=1;
    for(int i=0;i<n;i++)
    {
        int y=i,x=m-1;
        while(x>=0&&y>=0)
        {
            if(a[x][y]!=a[m-1][i])
                {   
                    l=0;
                    break;
                }
            x--,y--;
        }
        
    }
    if(l==1)
        printf("TRUE");
    else
        printf("Flase");
    return 0;
    
}