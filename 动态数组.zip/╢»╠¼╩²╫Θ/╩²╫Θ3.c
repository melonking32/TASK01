#include"stdio.h"
#include"stdlib.h"
int cmp(const void *a,const void *b){
    return (int*)a-(int*)b;
}
int main(){
    int n;
    scanf("%d",&n);
    int A[n];
    int B[10001]={0};
    int **result=(int**)malloc(1*sizeof(int*));
    int k=0;
    for(int i=0;i<1;i++)
        result[i]=(int *)malloc(sizeof(int)*n);
    for(int i=0;i<n;i++){
        scanf("%d",&A[i]);
        B[i]=1;
    }
    qsort(A,n,sizeof(A[0]),cmp);
    int i=0;
    int max=-1;
    while(A[i]<=0)
    {
        if(A[i]>max)
        {
            int j=i+1;
            int max2=-1;
            while(j<n&&A[j]<=-A[i])
            {
                if(B[0-A[i]-A[j]]==1&&A[j]>max2)
                  {
                        result[k][0]=A[i];
                        result[k][1]=A[j];
                        result[k][2]=0-A[i]-A[j];
                        k++;
                        result=(int**)realloc(result,(k+1)*sizeof(int*));
                        result[k]=(int*)malloc(sizeof(int)*3);
                        max2=A[j];
                    }
                //printf("%d %d %d\n",A[i],A[j],0-A[i]-A[j]);
                j++;
        }
        max=A[i];
        }
        i++;
    }
    for(int l=0;l<k;l++)
        printf("%d %d %d\n",result[l][0],result[l][1],result[l][2]);
    return 0;
}