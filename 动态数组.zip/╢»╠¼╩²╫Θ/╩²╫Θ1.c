#include"stdio.h"
#include"stdlib.h"
int main()
{
    int n;
    scanf("%d",&n);
    int *p=(int*)malloc(1*sizeof(int));
    int k=0;
    int i=2;
    while(i<n)
    {
        if(i%5==0||i%7==0)
        {
            p[k]=i;
            k++;
            p=(int*)realloc(p,(1+k)*sizeof(int));
        }
        i++;
    }
    for(int j=0;j<k;j++)
        printf("%d ",p[j]);
    return 0;
}